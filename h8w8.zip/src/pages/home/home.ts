import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';

@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
})
export class HomePage {
  public userDetails: any;
  items: any;
  id: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public menuCtrl: MenuController, public authService: AuthService) {
    const data = JSON.parse(localStorage.getItem('userData'));
    this.userDetails = data.userData;
    this.id = navParams.get('data');
  }

  ionViewDidLoad() {
    this.loadUser();
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false, 'authenticated');
    this.menuCtrl.enable(true, 'unauthenticated');
    console.log(this.id);
  }

  loadUser() {
    this.authService.profile(this.id).subscribe((std_profile) => {
      this.items = std_profile;
    });
  }

  doRefresh(refresher) {
    this.loadUser();
    setTimeout(() => {
      refresher.complete();
    }, 1000);
  }

}
