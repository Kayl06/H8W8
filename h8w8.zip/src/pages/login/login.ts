import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController, MenuController } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service'


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  responseData: any;
  userData = {
    username: '',
    password: ''
  }


  constructor(public navCtrl: NavController, public authService: AuthService, public alertCtrl: AlertController, public menuCtrl: MenuController) {
    // if (localStorage.getItem('userData')) {
    //   this.navCtrl.setRoot('LoginPage');
    // }
  }


  ionViewDidLoad() {
    this.menuCtrl.enable(false, 'authenticated');
    this.menuCtrl.enable(false, 'unauthenticated');
  }

  signIn() {
    if (this.userData.username == "" || this.userData.password == "") {
      let alert = this.alertCtrl.create({
        title: 'Warning',
        subTitle: 'Required Field/s',
        buttons: ['OK']
      });
      alert.present();
    }
    else {
      this.navCtrl.push('TabsPage');
      // this.authService.loginData(this.userData).then((result) => {
      //   this.responseData = result;
      //   if (this.responseData.userData) {
      //     this.userData = { username: '', password: '' }
      //     if (this.responseData.userData.position == "Doctor") {
      //       localStorage.setItem('userData', JSON.stringify(this.responseData));
      //       this.navCtrl.setRoot('DoctorPage');
      //     }
      //     else if (this.responseData.userData.position == "Student") {
      //       localStorage.setItem('userData', JSON.stringify(this.responseData));
      //       let id = this.responseData.userData.user_id;
      //       this.navCtrl.push('TabsPage', { data: id });
      //     } else {
      //       let alert = this.alertCtrl.create({
      //         title: 'This page is not available',
      //         buttons: ['OK']
      //       });
      //       alert.present();
      //     }
      //   }
      //   else {
      //     let alert = this.alertCtrl.create({
      //       title: 'Warning',
      //       subTitle: 'Invalid Username or Password ',
      //       buttons: ['OK']
      //     });
      //     alert.present();
      //   }
      // }, (err) => {
      //   // Error log
      // });
    }
  }

  registerPage() {
    this.navCtrl.push('RegisterPage');
  }

}
