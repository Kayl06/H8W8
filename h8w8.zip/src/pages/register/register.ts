import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service'

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  responseData: any;
  userData = {
    full_name: '',
    email: '',
    age: '',
    username: '',
    password: '',
    position: ''
  };

  constructor(public navCtrl: NavController,
    public authService: AuthService,
    public alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    // console.log('ionViewDidLoad RegisterPage');
  }

  registerAccount() {
    // console.log(this.userData);
    // if (this.userData.full_name == "" || this.userData.username == "" || this.userData.password == "" || this.userData.position == "") {
    //   let alert = this.alertCtrl.create({
    //     title: 'Warning',
    //     subTitle: 'Required Fields',
    //     buttons: ['OK']
    //   });
    //   alert.present();
    // }
    // else {
    //   this.authService.postData(this.userData).then((result) => {
    //     this.responseData = result;
    //     if (this.responseData) {
    //       let info = JSON.stringify(this.responseData)
    //       localStorage.setItem('userData', info);
    //       let alert = this.alertCtrl.create({
    //         title: 'Registered',
    //         buttons: ['OK']
    //       });
    //       alert.present();
    //       this.navCtrl.setRoot('LoginPage');
    //     } else {
    //       console.log('errrrr'); ``
    //     }
    //   }, (err) => {
    //     //Something error
    //   });
    // }
  }

  loginPage() {
    this.navCtrl.push('LoginPage');
  }

}
