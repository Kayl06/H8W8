import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController, App, PopoverController } from 'ionic-angular';
import { PopoverComponent } from '../../components/popover/popover';
import { AuthService } from '../../providers/auth-service';

@IonicPage()
@Component({
  selector: 'page-doctor',
  templateUrl: 'doctor.html',
})
export class DoctorPage {
  toggleValue: boolean = false;
  userDetails: any;
  responseData: any;
  values = '';
  search: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public menuCtrl: MenuController, public app: App,
    private popoverCtrl: PopoverController,
    public authService: AuthService) {
    // const data = JSON.parse(localStorage.getItem('userData'));
    // this.userDetails = data.userData;
    // this.userDetails = this.authService.usersFetch();
  }
  ionViewDidLoad() {
    this.menuCtrl.enable(true, 'authenticated');
    this.menuCtrl.enable(false, 'unauthenticated');
    this.loadUsers();
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true, 'authenticated');
    this.menuCtrl.enable(false, 'unauthenticated');
    this.menuCtrl.close();
  }

  loadUsers() {
    this.authService.usersFetch().subscribe((posts) => {
      this.userDetails = posts;
    });
  }

  presentPopover(myEvent) {
    let popover = this.popoverCtrl.create(PopoverComponent);
    popover.present({
      ev: myEvent
    });
  }

  doRefresh(refresher) {
    this.loadUsers();
    setTimeout(() => {
      refresher.complete();
    }, 1500);
  }

  onChange(){
    if(this.toggleValue == true){
      console.log("On");
      
    }else{
      console.log("Off");
    }
  }


  idol(user_id) {

  }

}
