import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, MenuController } from 'ionic-angular';
import * as HighCharts from 'highcharts';
import { AuthService } from '../../providers/auth-service';
@IonicPage()
@Component({
  selector: 'page-analytics',
  templateUrl: 'analytics.html',
})
export class AnalyticsPage {
  bmi: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public menuCtrl: MenuController, public authService: AuthService) {
  }


  ionViewDidLoad() {
    this.loadBMI();
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true, 'authenticated');
    this.menuCtrl.enable(false, 'unauthenticated');
    this.menuCtrl.close();
  }
  ionViewWillLeave() {
    this.menuCtrl.open();
  }

  doRefresh(refresher) {
    this.loadBMI();
    setTimeout(() => {
      refresher.complete();
    }, 1500);
  }

  loadBMI() {
    var series = [];
    this.authService.bmiChart().subscribe((bmi) => {
      this.bmi = bmi;
      for (let i of this.bmi) {
        series.push(JSON.parse(i.total_underweight));
        series.push(JSON.parse(i.total_normal));
        series.push(JSON.parse(i.total_overweight));
        series.push(JSON.parse(i.total_obese));
      }
      HighCharts.chart('container', {
        chart: {
          backgroundColor: {
            linearGradient: [500, 0, 0, 500],
            stops: [
              [0, 'rgb(255, 255, 255)'],
              [1, '#384552']
            ]
          },
          height: '370',
          type: 'spline',
          style: { "fontFamily": "Open Sans", "fontSize": "14px", "font-weight": "bold" },
          // backgroundColor: "#eeeeee",
        },
        title: {
          text: 'BMI Chart',
          style: { "fontFamily": "Bebas Neue", "fontSize": "30px", "color": "#242a31", "font-weight": "bold", "letter-spacing": ".2rem" }
        },
        xAxis: {
          categories: ['Underweight', 'Normal', 'Overweight', 'Obese'],
          gridLineWidth: 1,
          lineColor: '#000',
          tickColor: '#000',
          labels: {
            style: {
              color: '#000',
              font: '11px Trebuchet MS, Verdana, sans-serif'
            }
          },
          title: {
            style: {
              color: '#00',
              fontWeight: 'bold',
              fontSize: '12px',
            }
          }
        },
        yAxis: {
          tickColor: '#000',
          labels: {
            style: {
              color: '#242a31',
              font: '11px Trebuchet MS, Verdana, sans-serif'
            }
          },
          title: {
            text: "Values",
            style: {
              color: '#242a31',
              fontWeight: 'bold',
              fontSize: '15px',
              fontFamily: 'Bebas Neue',
            }
          }
        },
        series: [{
          name: 'BMI',
          data: series,
          color: '#3d4f62'
        }]
      });
    });
  }
}
