import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-tabs',
  templateUrl: 'tabs.html'
})
export class TabsPage {

  homeRoot = 'HomePage'
  aboutRoot = 'AboutPage'
  settingsRoot = 'SettingsPage'
  id: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.navParams = navParams;
    this.id = this.navParams.data;
  }
}
