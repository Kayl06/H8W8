import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-dashboard',
  templateUrl: 'dashboard.html',
})
export class DashboardPage {
  public userDetails: any;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    const data = JSON.parse(localStorage.getItem('userData'));
    this.userDetails = data.userData;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DashboardPage');
  }

  backtoLoginPage() {
    this.navCtrl.setRoot('LoginPage');
  }

  logout() {
    localStorage.clear();
    setTimeout(() => this.backtoLoginPage(), 1000);
  }

}
