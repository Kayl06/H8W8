import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, App } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';

@IonicPage()
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html',
})
export class SettingsPage {
  items: any;
  id: any;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    public app: App,
    public authService: AuthService) {
    this.id = navParams.get('data');
  }

  ionViewDidLoad() {
    // this.loadUser();
  }

  ionViewWillEnter() {
    console.log(this.id);
  }

  backtoLoginPage() {
    // const root = this.app.getRootNav();
    // root.popToRoot();
    let newRootNav = <NavController>this.app.getRootNavById('n4');
    newRootNav.push('LoginPage');
  }

  // loadUser() {
  //   this.authService.profile(this.id).subscribe((std_profile) => {
  //     this.items = std_profile;
  //   });
  // }

  logout() {
    localStorage.clear();
    setTimeout(() => this.backtoLoginPage(), 1000);
  }

}
