import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { HttpModule } from '@angular/http';
import { ChartsModule } from 'ng2-charts';


import { MyApp } from './app.component';
import { AuthService } from '../providers/auth-service';
import { PopoverComponent } from '../components/popover/popover';


@NgModule({
  declarations: [
    MyApp,
    PopoverComponent
    // HomePage,
    // LoginPage,
    // RegisterPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    ChartsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    PopoverComponent
    // HomePage,
    // LoginPage,
    // RegisterPage
  ],
  providers: [
    StatusBar,
    SplashScreen, AuthService,
    { provide: ErrorHandler, useClass: IonicErrorHandler }
  ]
})
export class AppModule { }
