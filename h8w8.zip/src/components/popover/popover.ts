import { Component } from '@angular/core';
import { NavController, ViewController } from 'ionic-angular';
import { App } from 'ionic-angular';

@Component({
  selector: 'popover',
  templateUrl: 'popover.html'
})
export class PopoverComponent {
  items: any;
  text: string;

  constructor(public app: App, public navCtrl: NavController, public viewCtrl: ViewController) {
    this.items = [
      { item: 'Log-out' },
      // { item: 'Profile' }
    ]
  }

  backtoLoginPage() {
    let newRootNav = <NavController>this.app.getRootNavById('n4');
    newRootNav.push('LoginPage');
  }

  logout() {
    localStorage.clear();
    setTimeout(() => this.backtoLoginPage(), 1000);
    this.viewCtrl.dismiss();
  }

}
