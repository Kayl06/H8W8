import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import 'rxjs/add/operator/map';

let apiUrl = "http://localhost/api/h8w8/"; //192.168.100.63

@Injectable()
export class AuthService {
  users: any;

  constructor(public http: Http) {
    // console.log('Hello AuthServiceProvider Provider');
  }
  postData(credentials) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      let cred = JSON.stringify(credentials);
      this.http.post(apiUrl + 'register.php', cred, { headers: headers }).subscribe(res => {
        resolve(res.json());
      }, (err) => {
        reject(err);
      });
    });
  }

  loginData(credentials) {
    return new Promise((resolve, reject) => {
      let headers = new Headers();
      let cred = JSON.stringify(credentials);
      this.http.post(apiUrl + 'login.php', cred, { headers: headers }).subscribe(res => {
        resolve(res.json());
      }, (err) => {
        reject(err);
      });
    });
  }

  usersFetch() {
    return this.http.get(apiUrl + 'select.php').map(res => res.json());
  }

  profile(user_id) {
    return this.http.get(apiUrl + 'select.php?user_id=' + user_id).map(res => res.json());
  }

  bmiChart(){
    return this.http.get(apiUrl + 'bmichart.php').map(res => res.json());
  }

  profileSearch() {
    // const identitys = JSON.stringify(identity);
    // return this.http.post(apiUrl + 'search.php', identitys).map(res => res.json());
  }

}
